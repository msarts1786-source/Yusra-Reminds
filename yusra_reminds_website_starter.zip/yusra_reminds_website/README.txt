YUSRA REMINDS — STARTER WEBSITE

Files:
- index.html: complete responsive website
- assets/welcome-arch.png: generated welcome artwork (if included)

Preview:
Open index.html in a browser. The first visit asks for a name; the name is saved in that browser using localStorage. Returning visitors go straight to the homepage.

Important:
This is a starter website. It is not online until you host it. For a free public link, upload these files to a public GitHub repository and enable GitHub Pages. The name prompt is a friendly welcome feature, not account verification, and the name is stored only in the visitor's browser.
